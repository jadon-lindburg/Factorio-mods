require("prototypes.item.steel-gear-wheel")

require("prototypes.recipe.steel-gear-wheel")

require("prototypes.technology.steel-processing")