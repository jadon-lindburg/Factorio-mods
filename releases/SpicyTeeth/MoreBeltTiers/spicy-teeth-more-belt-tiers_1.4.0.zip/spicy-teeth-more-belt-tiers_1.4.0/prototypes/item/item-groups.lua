data:extend(
{
  {
    type = "item-subgroup",
    name = "extended-belt",
    group = "extended-logistics",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "extended-underground-belt",
    group = "extended-logistics",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "extended-splitter",
    group = "extended-logistics",
    order = "c"
  }
}
)
