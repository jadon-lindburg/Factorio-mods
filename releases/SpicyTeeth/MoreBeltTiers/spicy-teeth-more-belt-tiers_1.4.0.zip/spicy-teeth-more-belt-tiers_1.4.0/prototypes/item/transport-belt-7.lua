data:extend(
{
  {
    type = "item",
    name = "transport-belt-7",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/transport-belt-7.png",
    icon_size = 32,
    subgroup = "extended-belt",
    order = "g[transport-belt-7]",
    place_result = "transport-belt-7",
    stack_size = 100
  },
}
)
