data.raw["underground-belt"]["express-underground-belt"].next_upgrade = "underground-belt-4"
