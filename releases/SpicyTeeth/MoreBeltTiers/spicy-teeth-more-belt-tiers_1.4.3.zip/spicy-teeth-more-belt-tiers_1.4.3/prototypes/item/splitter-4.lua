data:extend(
{
  {
    type = "item",
    name = "splitter-4",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/splitter-4.png",
    icon_size = 32,
    subgroup = "extended-splitter",
    order = "d[splitter-4]",
    place_result = "splitter-4",
    stack_size = 50
  },
}
)
