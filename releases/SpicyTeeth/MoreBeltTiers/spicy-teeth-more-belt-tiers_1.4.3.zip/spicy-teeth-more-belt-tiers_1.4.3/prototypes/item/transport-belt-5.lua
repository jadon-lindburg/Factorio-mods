data:extend(
{
  {
    type = "item",
    name = "transport-belt-5",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/transport-belt-5.png",
    icon_size = 32,
    subgroup = "extended-belt",
    order = "e[transport-belt-5]",
    place_result = "transport-belt-5",
    stack_size = 100
  },
}
)
