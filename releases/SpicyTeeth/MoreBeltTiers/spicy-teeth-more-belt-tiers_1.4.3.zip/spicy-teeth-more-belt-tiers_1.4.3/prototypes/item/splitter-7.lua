data:extend(
{
  {
    type = "item",
    name = "splitter-7",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/splitter-7.png",
    icon_size = 32,
    subgroup = "extended-splitter",
    order = "g[splitter-7]",
    place_result = "splitter-7",
    stack_size = 50
  },
}
)
