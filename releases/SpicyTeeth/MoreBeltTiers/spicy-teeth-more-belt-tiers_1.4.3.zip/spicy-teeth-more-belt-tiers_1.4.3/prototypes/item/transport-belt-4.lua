data:extend(
{
  {
    type = "item",
    name = "transport-belt-4",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/transport-belt-4.png",
    icon_size = 32,
    subgroup = "extended-belt",
    order = "d[transport-belt-4]",
    place_result = "transport-belt-4",
    stack_size = 100
  },
}
)
