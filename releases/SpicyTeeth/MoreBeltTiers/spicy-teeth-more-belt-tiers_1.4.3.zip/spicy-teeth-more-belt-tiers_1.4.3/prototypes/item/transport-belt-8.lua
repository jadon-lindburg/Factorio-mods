data:extend(
{
  {
    type = "item",
    name = "transport-belt-8",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/transport-belt-8.png",
    icon_size = 32,
    subgroup = "extended-belt",
    order = "h[transport-belt-8]",
    place_result = "transport-belt-8",
    stack_size = 100
  },
}
)
