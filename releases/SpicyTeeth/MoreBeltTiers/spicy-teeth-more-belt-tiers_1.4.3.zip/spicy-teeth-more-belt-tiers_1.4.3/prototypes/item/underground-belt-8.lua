data:extend(
{
  {
    type = "item",
    name = "underground-belt-8",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/underground-belt-8.png",
    icon_size = 32,
    subgroup = "extended-underground-belt",
    order = "h[underground-belt-8]",
    place_result = "underground-belt-8",
    stack_size = 50
  },
}
)
