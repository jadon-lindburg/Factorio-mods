tier_8_belt_animation_set =
{
  animation_set =
  {
    filename = "__spicy-teeth-mbt_assets__/graphics/entity/transport-belt-8/transport-belt-8.png",
    priority = "extra-high",
    width = 64,
    height = 64,
    frame_count = 32,
    direction_count = 20,
    hr_version =
    {
      filename = "__spicy-teeth-mbt_assets__/graphics/entity/transport-belt-8/hr-transport-belt-8.png",
      priority = "extra-high",
      width = 128,
      height = 128,
      scale = 0.5,
      frame_count = 32,
      direction_count = 20,
    }
  },
}
