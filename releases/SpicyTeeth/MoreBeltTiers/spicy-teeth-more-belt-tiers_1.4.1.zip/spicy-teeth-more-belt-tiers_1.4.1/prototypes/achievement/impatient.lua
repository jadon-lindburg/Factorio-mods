data:extend(
{
  {
    type = "produce-achievement",
    name = "impatient",
    order = "a[progress]-e[impatient]",
    item_product = "transport-belt-4",
    icon = "__spicy-teeth-mbt_assets__/graphics/achievement/impatient.png",
    icon_size = 128,
    limited_to_one_game=false,
    amount=1
  }
}
)
