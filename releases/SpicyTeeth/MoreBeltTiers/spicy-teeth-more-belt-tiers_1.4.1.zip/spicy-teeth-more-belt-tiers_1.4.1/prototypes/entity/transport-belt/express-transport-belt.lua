data.raw["transport-belt"]["express-transport-belt"].next_upgrade = "transport-belt-4"
