data:extend(
{
  {
    type = "item",
    name = "splitter-6",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/splitter-6.png",
    icon_size = 32,
    subgroup = "extended-splitter",
    order = "f[splitter-6]",
    place_result = "splitter-6",
    stack_size = 50
  },
}
)
