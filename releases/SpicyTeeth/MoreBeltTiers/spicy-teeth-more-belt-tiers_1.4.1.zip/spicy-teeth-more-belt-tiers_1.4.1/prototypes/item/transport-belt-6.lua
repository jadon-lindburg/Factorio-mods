data:extend(
{
  {
    type = "item",
    name = "transport-belt-6",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/transport-belt-6.png",
    icon_size = 32,
    subgroup = "extended-belt",
    order = "f[transport-belt-6]",
    place_result = "transport-belt-6",
    stack_size = 100
  },
}
)
