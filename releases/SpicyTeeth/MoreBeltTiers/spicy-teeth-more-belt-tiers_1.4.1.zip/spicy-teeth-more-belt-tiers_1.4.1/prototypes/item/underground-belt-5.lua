data:extend(
{
  {
    type = "item",
    name = "underground-belt-5",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/underground-belt-5.png",
    icon_size = 32,
    subgroup = "extended-underground-belt",
    order = "e[underground-belt-5]",
    place_result = "underground-belt-5",
    stack_size = 50
  },
}
)
