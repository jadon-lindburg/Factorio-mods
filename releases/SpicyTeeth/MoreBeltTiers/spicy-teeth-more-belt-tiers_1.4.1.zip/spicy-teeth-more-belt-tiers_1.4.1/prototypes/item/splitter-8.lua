data:extend(
{
  {
    type = "item",
    name = "splitter-8",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/splitter-8.png",
    icon_size = 32,
    subgroup = "extended-splitter",
    order = "h[splitter-8]",
    place_result = "splitter-8",
    stack_size = 50
  },
}
)
