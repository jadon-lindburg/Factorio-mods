data:extend(
{
  {
    type = "item",
    name = "splitter-5",
    icon = "__spicy-teeth-mbt_assets__/graphics/icons/splitter-5.png",
    icon_size = 32,
    subgroup = "extended-splitter",
    order = "e[splitter-5]",
    place_result = "splitter-5",
    stack_size = 50
  },
}
)
