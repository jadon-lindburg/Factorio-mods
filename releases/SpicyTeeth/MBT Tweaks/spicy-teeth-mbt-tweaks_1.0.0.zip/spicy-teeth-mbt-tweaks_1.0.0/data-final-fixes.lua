-- store prototypes to change
local __splitter__splitter_4 = data.raw["splitter"]["splitter-4"]
local __transport_belt__transport_belt_4 = data.raw["transport-belt"]["transport-belt-4"]
local __underground_belt__underground_belt_4 = data.raw["underground-belt"]["underground-belt-4"]
-- / store prototypes to change



-- modify speed of MBT belt tiers
--   splitters
__splitter__splitter_4.speed = 0.125   -- 60 items/sec
--   transport belts
__transport_belt__transport_belt_4.speed = 0.125
--   underground belts
__underground_belt__underground_belt_4.speed = 0.125
-- /modify speed of MBT belt tiers