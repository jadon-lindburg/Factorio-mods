data.raw["technology"]["steel-processing"].effects =
{
  {
    type = "unlock-recipe",
    recipe = "steel-plate"
  },
  {
    type = "unlock-recipe",
    recipe = "steel-gear-wheel"
  },
  {
    type = "unlock-recipe",
    recipe = "steel-chest"
  }
}
