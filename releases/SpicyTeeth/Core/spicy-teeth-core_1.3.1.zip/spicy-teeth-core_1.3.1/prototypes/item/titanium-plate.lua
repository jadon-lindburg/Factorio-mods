data:extend(
{
  {
    type = "item",
    name = "titanium-plate",
    icon = "__spicy-teeth-core_assets__/graphics/icons/titanium-plate.png",
    icon_size = 32,
    subgroup = "raw-material",
    order = "e[titanium-plate]",
    stack_size = 100
  }
}
)
