data:extend(
{
  {
    type = "item",
    name = "steel-gear-wheel",
    icon = "__spicy-teeth-core_assets__/graphics/icons/steel-gear-wheel.png",
    icon_size = 32,
    subgroup = "intermediate-product",
    order = "ca[steel-gear-wheel]",
    stack_size = 100
  }
}
)
