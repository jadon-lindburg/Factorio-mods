data:extend(
{
  {
    type = "item",
    name = "titanium-gear-wheel",
    icon = "__spicy-teeth-core_assets__/graphics/icons/titanium-gear-wheel.png",
    icon_size = 32,
    subgroup = "intermediate-product",
    order = "cb[titanium-gear-wheel]",
    stack_size = 100
  }
}
)
