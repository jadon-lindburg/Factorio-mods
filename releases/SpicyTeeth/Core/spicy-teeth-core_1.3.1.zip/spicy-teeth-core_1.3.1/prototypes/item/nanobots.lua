data:extend(
{
  {
    type = "item",
    name = "nanobots",
    icon = "__spicy-teeth-core_assets__/graphics/icons/nanobots.png",
    icon_size = 32,
    subgroup = "intermediate-product",
    order = "j[nanobots]",
    stack_size = 100
  }
}
)
