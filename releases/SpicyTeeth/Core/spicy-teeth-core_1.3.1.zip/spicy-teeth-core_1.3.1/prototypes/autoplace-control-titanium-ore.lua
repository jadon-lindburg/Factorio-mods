data:extend(
{
  {
    type = "autoplace-control",
    name = "titanium-ore",
    richness = true,
    order = "b-ba",
    category = "resource"
  }
}
)