data:extend(
{
  {
    type = "recipe",
    name = "nanobots",
	enabled = false,
    ingredients =
    {
      {"titanium-plate", 10},
      {"electronic-circuit", 10},
      {"electric-engine-unit", 5}
    },
    result_count = 5,
    result = "nanobots"
  }
}
)
