require("prototypes.fluid.refined-lubricant")

require("prototypes.item.steel-gear-wheel")

require("prototypes.recipe.fluid-refined-lubricant")
require("prototypes.recipe.steel-gear-wheel")

require("prototypes.technology.refined-lubricant")
require("prototypes.technology.steel-processing")