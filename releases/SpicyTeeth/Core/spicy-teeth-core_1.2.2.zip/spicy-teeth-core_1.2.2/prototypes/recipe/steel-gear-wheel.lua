data:extend(
{
  {
    type = "recipe",
    name = "steel-gear-wheel",
    normal =
    {
      enabled = false,
      ingredients = {{"steel-plate", 2}},
      result = "steel-gear-wheel"
    },
    expensive =
    {
      enabled = false,
      ingredients = {{"steel-plate", 4}},
      result = "steel-gear-wheel"
    }
  }
}
)
