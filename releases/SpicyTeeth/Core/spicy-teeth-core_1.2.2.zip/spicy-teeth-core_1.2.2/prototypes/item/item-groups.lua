data:extend(
{
  {
    type = "item-group",
    name = "extended-logistics",
    icon = "__spicy-teeth-core_assets__/graphics/item-group/extended-logistics.png",
    icon_size = 64,
    order = "aab"
  }
}
)
