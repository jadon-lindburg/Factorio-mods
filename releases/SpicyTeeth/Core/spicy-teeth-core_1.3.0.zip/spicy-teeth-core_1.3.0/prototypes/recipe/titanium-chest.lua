data:extend(
{
  {
    type = "recipe",
    name = "titanium-chest",
    ingredients = {{"titanium-plate", 20}},
    result = "titanium-chest"
  }
}
)
