data:extend(
{
  {
    type = "item",
    name = "titanium-chest",
    icon = "__spicy-teeth-core_assets__/graphics/icons/titanium-chest.png",
    icon_size = 32,
    subgroup = "storage",
    order = "a[items]-ca[titanium-chest]",
    place_result = "titanium-chest",
    stack_size = 50
  }
}
)
