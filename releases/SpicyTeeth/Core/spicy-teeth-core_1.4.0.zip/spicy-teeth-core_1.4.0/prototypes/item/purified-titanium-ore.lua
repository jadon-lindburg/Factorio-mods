data:extend(
{
  {
    type = "item",
    name = "purified-titanium-ore",
    icon = "__spicy-teeth-core_assets__/graphics/icons/purified-titanium-ore.png",
    icon_size = 32,
    subgroup = "raw-material",
    order = "e-a[purified-titanium-ore]",
    stack_size = 50
  }
}
)
