data:extend(
{
  {
    type = "recipe",
    name = "titanium-gear-wheel",
    normal =
    {
	  enabled = false,
      ingredients = {{"titanium-plate", 2}},
      result = "titanium-gear-wheel"
    },
    expensive =
    {
	  enabled = false,
      ingredients = {{"titanium-plate", 4}},
      result = "titanium-gear-wheel"
    }
  }
}
)
