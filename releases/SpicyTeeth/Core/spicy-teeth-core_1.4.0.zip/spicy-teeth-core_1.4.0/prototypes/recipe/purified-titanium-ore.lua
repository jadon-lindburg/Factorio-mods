data:extend(
{
  {
    type = "recipe",
    name = "purified-titanium-ore",
	category = "crafting-with-fluid",
	enabled = false,
    ingredients =
	{
	  {"titanium-ore", 1},
	  {type="fluid", name="sulfuric-acid", amount=5}
	},
    result = "purified-titanium-ore"
  }
}
)
