data:extend(
{
  {
    type = "recipe",
    name = "titanium-chest",
	enabled = false,
    ingredients = {{"titanium-plate", 8}},
    result = "titanium-chest"
  }
}
)
