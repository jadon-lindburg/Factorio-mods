data:extend(
{
    {
        type = "item",
        name = "steel-gear-wheel",
        icon = "__spicy-teeth-core__/graphics/icons/steel-gear-wheel.png",
        icon_size = 32,
        subgroup = "intermediate-product",
        order = "c[steel-gear-wheel]",
        stack_size = 100
    }
}
)